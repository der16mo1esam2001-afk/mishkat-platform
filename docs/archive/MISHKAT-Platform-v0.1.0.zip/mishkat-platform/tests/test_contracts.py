from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def test_five_independent_database_migrations_exist():
    domains = {"vitalis", "aquanex", "agronex", "energis", "nexora"}
    for domain in domains:
        migration = ROOT / "database" / domain / "02-schema.sql"
        assert migration.exists(), f"Missing database schema for {domain}"
        text = migration.read_text(encoding="utf-8")
        assert "ENABLE ROW LEVEL SECURITY" in text
        assert "FORCE ROW LEVEL SECURITY" in text
        assert "owner_id = app_private.current_user_id()" in text
        assert "BYPASSRLS" not in text


def test_domain_database_urls_are_separate_in_compose():
    compose = (ROOT / "docker-compose.yml").read_text(encoding="utf-8")
    for name in ("vitalis", "aquanex", "agronex", "energis", "nexora"):
        assert f"{name}_data:" in compose
        assert f"{name}-db:" in compose
        assert f"{name.upper()}_DB_URL" in compose
        assert f"@{name}-db:5432/{name}" in compose


def test_no_real_world_fake_kpis_in_dashboard():
    html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    assert "لا تُعرض بيانات افتراضية" in html
    assert "بانتظار الاتصال" in html
    assert "86%" not in html and "92%" not in html


def test_nasa_connector_is_documented_and_validates_missing_values():
    backend = (ROOT / "backend" / "app" / "main.py").read_text(encoding="utf-8")
    assert "/connectors/nasa-power/fetch" in backend
    assert "ALLSKY_SFC_SW_DWN" in backend
    assert "-999" in backend
    assert "NASA POWER Daily API" in backend


def test_source_registry_contains_all_critical_public_sources():
    catalog = (ROOT / "backend" / "app" / "catalog.py").read_text(encoding="utf-8")
    for source in ("WHO Global Health Observatory", "Aqueduct 4.0", "FAOSTAT API", "FAO WaPOR v3", "NASA POWER Daily API", "Ember Data API", "UNESCO Institute for Statistics"):
        assert source in catalog


def test_dev_auth_is_separate_from_production_auth_mode():
    security = (ROOT / "backend" / "app" / "security.py").read_text(encoding="utf-8")
    assert "settings.auth_mode == \"development\"" in security
    assert "settings.auth_mode == \"supabase_jwks\"" in security
    assert "settings.dev_auth_enabled" in security


def test_api_liveness_and_explicit_unconfigured_ai():
    import sys
    sys.path.insert(0, str(ROOT / "backend"))
    from fastapi.testclient import TestClient
    from app.main import app

    with TestClient(app) as client:
        home = client.get("/")
        assert home.status_code == 200 and "MISHKAT" in home.text
        manifest = client.get("/manifest.webmanifest")
        assert manifest.status_code == 200 and manifest.json()["display"] == "standalone"
        sw = client.get("/sw.js")
        assert sw.status_code == 200 and "api/" in sw.text
        live = client.get("/api/v1/health/live")
        assert live.status_code == 200
        token = client.post("/api/v1/auth/dev-token")
        assert token.status_code == 200
        headers = {"Authorization": f"Bearer {token.json()['access_token']}"}
        ai = client.get("/api/v1/ai/status", headers=headers)
        assert ai.status_code == 200
        assert ai.json()["status"] == "not_configured"
        bad_ag = client.post("/api/v1/connectors/nasa-power/fetch", headers=headers, json={"latitude": 30, "longitude": 31, "start_date": "2026-10-01", "end_date": "2026-10-02", "community": "AG", "parameters": ["ALLSKY_SFC_SW_DWN"]})
        assert bad_ag.status_code == 422
        bad_re = client.post("/api/v1/connectors/nasa-power/fetch", headers=headers, json={"latitude": 30, "longitude": 31, "start_date": "2026-10-01", "end_date": "2026-10-02", "community": "RE", "parameters": ["T2M"]})
        assert bad_re.status_code == 422
        sources = client.get("/api/v1/evidence/sources", headers=headers)
        assert sources.status_code == 200
        assert len(sources.json()["items"]) >= 7


def test_pwa_does_not_cache_api_or_sensitive_responses():
    sw = (ROOT / "frontend" / "sw.js").read_text(encoding="utf-8")
    assert "url.pathname.startsWith('/api/')" in sw
    assert "Never cache API responses" in sw
    assert "caches.match" in sw


def test_common_provenance_and_model_registry_are_isolated():
    for domain in ("vitalis", "aquanex", "agronex", "energis", "nexora"):
        sql = (ROOT / "database" / domain / "02-schema.sql").read_text(encoding="utf-8")
        for table in ("ingestion_runs", "model_registry"):
            assert f"CREATE TABLE IF NOT EXISTS public.{table}" in sql
            assert f"ALTER TABLE public.{table} ENABLE ROW LEVEL SECURITY" in sql
            assert f"ALTER TABLE public.{table} FORCE ROW LEVEL SECURITY" in sql
    assert "CREATE EXTENSION IF NOT EXISTS postgis" in (ROOT / "database" / "common_rls.sql").read_text(encoding="utf-8")


def test_nasa_import_is_linked_to_an_ingestion_run_and_audit_event():
    backend = (ROOT / "backend" / "app" / "main.py").read_text(encoding="utf-8")
    assert "INSERT INTO public.ingestion_runs" in backend
    assert "ingestion_run_id" in backend
    assert "INSERT INTO public.audit_events" in backend
    assert "status='completed'" in backend


def test_foreign_keys_enforce_owner_boundary():
    for domain in ("vitalis", "aquanex", "agronex", "energis", "nexora"):
        sql = (ROOT / "database" / domain / "02-schema.sql").read_text(encoding="utf-8")
        # Domain tables must not use a naked id-only FK to another tenant-owned table.
        assert not re.search(r"REFERENCES public\.[a-z_]+\(id\)", sql)
        assert "FOREIGN KEY (owner_id," in sql or domain == "aquanex"

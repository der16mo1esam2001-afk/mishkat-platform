"""MISHKAT platform backend."""

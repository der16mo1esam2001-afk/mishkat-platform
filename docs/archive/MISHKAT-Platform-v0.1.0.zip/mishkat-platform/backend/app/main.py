from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import date, datetime
from typing import Any, Literal

import httpx
from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .catalog import SOURCE_AS_OF, SOURCES, WORKSPACES
from .database import db_hub
from .security import Principal, get_current_principal, issue_local_development_token
from .settings import settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        db_hub.open()
    except Exception as exc:  # report a degraded start instead of hiding the failure
        app.state.database_start_error = f"{type(exc).__name__}: {exc}"
    yield
    db_hub.close()


app = FastAPI(
    title="MISHKAT Intelligence Platform API",
    version="0.1.0",
    description="Unified application gateway for five independently isolated sector workspaces.",
    docs_url="/docs" if settings.environment == "development" else None,
    redoc_url="/redoc" if settings.environment == "development" else None,
    openapi_url="/openapi.json" if settings.environment == "development" else None,
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

from pathlib import Path

_FILE = Path(__file__).resolve()
_FRONTEND_CANDIDATES = [_FILE.parents[2] / "frontend", _FILE.parents[1] / "frontend"]
FRONTEND_DIR = next((candidate for candidate in _FRONTEND_CANDIDATES if candidate.is_dir()), _FRONTEND_CANDIDATES[0])
app.mount("/assets", StaticFiles(directory=FRONTEND_DIR / "assets"), name="assets")


@app.get("/", include_in_schema=False)
def homepage():
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/manifest.webmanifest", include_in_schema=False)
def pwa_manifest():
    return FileResponse(FRONTEND_DIR / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/sw.js", include_in_schema=False)
def service_worker():
    return FileResponse(FRONTEND_DIR / "sw.js", media_type="application/javascript", headers={"Cache-Control": "no-cache"})


@app.get("/api/v1/health/live", tags=["operations"])
def liveness():
    return {"status": "alive", "service": "mishkat-api", "version": app.version}


@app.get("/api/v1/health/ready", tags=["operations"])
def readiness():
    statuses = db_hub.check()
    ready = bool(statuses) and all(value == "connected" for value in statuses.values())
    return {"status": "ready" if ready else "degraded", "databases": statuses}


@app.post("/api/v1/auth/dev-token", tags=["authentication"])
def dev_token():
    """Local-only token for the closed development environment. Never enabled in production."""
    return issue_local_development_token()


@app.get("/api/v1/system/overview", tags=["system"])
def system_overview(principal: Principal = Depends(get_current_principal)):
    statuses = db_hub.check()
    return {
        "platform": "MISHKAT",
        "authenticated_user": str(principal.user_id),
        "database_isolation": "five independent PostgreSQL databases",
        "databases": statuses,
        "all_databases_connected": all(value == "connected" for value in statuses.values()),
        "warning": "A connected database does not prove domain data quality, external integrations, or production readiness.",
    }


@app.get("/api/v1/workspaces", tags=["workspaces"])
def workspaces(principal: Principal = Depends(get_current_principal)):
    return {"items": WORKSPACES}


@app.get("/api/v1/evidence/sources", tags=["evidence"])
def evidence_sources(principal: Principal = Depends(get_current_principal)):
    return {"as_of": SOURCE_AS_OF, "items": SOURCES}


@app.get("/api/v1/ai/status", tags=["ai-governance"])
def ai_status(principal: Principal = Depends(get_current_principal)):
    return {
        "status": "not_configured",
        "inference_enabled": False,
        "message": "No AI model provider is connected in this engineering package. No generated answer or prediction is being simulated.",
        "required_before_enablement": ["approved provider and data-processing terms", "server-side secret management", "domain-specific safety policy", "evaluation dataset and independent acceptance tests"],
    }


class NasaPowerRequest(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    start_date: date
    end_date: date
    parameters: list[str] = Field(default_factory=lambda: ["T2M", "PRECTOTCORR"], min_length=1, max_length=20)
    community: Literal["AG", "RE"] = "AG"


ALLOWED_NASA_PARAMETERS = {
    "AG": {"T2M", "T2M_MAX", "T2M_MIN", "PRECTOTCORR", "RH2M", "WS10M"},
    "RE": {"ALLSKY_SFC_SW_DWN"},
}


@app.post("/api/v1/connectors/nasa-power/fetch", tags=["connectors"])
async def fetch_nasa_power(payload: NasaPowerRequest, principal: Principal = Depends(get_current_principal)):
    if payload.end_date < payload.start_date:
        raise HTTPException(status_code=422, detail="end_date must be on or after start_date")
    if (payload.end_date - payload.start_date).days > 370:
        raise HTTPException(status_code=422, detail="A maximum 371-day interval is allowed per request")
    requested = [p.upper() for p in payload.parameters]
    invalid = sorted(set(requested) - ALLOWED_NASA_PARAMETERS[payload.community])
    if invalid:
        raise HTTPException(status_code=422, detail={"invalid_parameters": invalid, "community": payload.community, "allowed": sorted(ALLOWED_NASA_PARAMETERS[payload.community])})

    params = {
        "parameters": ",".join(requested),
        "community": payload.community,
        "longitude": payload.longitude,
        "latitude": payload.latitude,
        "start": payload.start_date.strftime("%Y%m%d"),
        "end": payload.end_date.strftime("%Y%m%d"),
        "format": "JSON",
        "time-standard": "UTC",
    }
    try:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            response = await client.get(settings.nasa_power_base_url, params=params)
            response.raise_for_status()
            raw = response.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise HTTPException(status_code=502, detail=f"NASA POWER request failed: {type(exc).__name__}") from exc

    properties = raw.get("properties", {})
    parameter_data = properties.get("parameter", {})
    parameter_metadata = raw.get("parameters", {})
    if not parameter_data:
        raise HTTPException(status_code=502, detail="NASA POWER returned no parameter series")

    rows: list[dict[str, Any]] = []
    for parameter, observations in parameter_data.items():
        meta = parameter_metadata.get(parameter, {}) if isinstance(parameter_metadata, dict) else {}
        source_unit = meta.get("units") or meta.get("unit") or _nasa_unit(parameter)
        for timestamp, value in observations.items():
            rows.append({"date": timestamp, "parameter": parameter, "value": value, "unit": source_unit})

    # Persist observations only in the owning sector database selected by NASA community.
    domain, table = ("agronex", "weather_observations") if payload.community == "AG" else ("energis", "resource_observations")
    persisted = {domain: 0}
    correlation_id = str(__import__("uuid").uuid4())
    for domain, table in ((domain, table),):
        try:
            with db_hub.user_connection(domain, principal) as conn:
                run = conn.execute(
                    """INSERT INTO public.ingestion_runs
                    (owner_id, source_id, target_dataset, status, started_at, request_metadata, license_snapshot)
                    VALUES (%s, 'nasa_power', %s, 'running', now(), %s::jsonb, 'NASA POWER source terms; attribution retained')
                    RETURNING id""",
                    (str(principal.user_id), table,
                     __import__("json").dumps({"latitude": payload.latitude, "longitude": payload.longitude,
                                                "start": payload.start_date.isoformat(), "end": payload.end_date.isoformat(),
                                                "parameters": requested, "time_standard": "UTC"})),
                ).fetchone()
                ingestion_run_id = str(run["id"])
                for row in rows:
                    conn.execute(
                        f"""INSERT INTO {table}
                        (owner_id, observation_date, parameter_code, value, unit, latitude, longitude,
                         source_id, ingestion_run_id, raw_value)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, 'nasa_power', %s, %s::jsonb)
                        ON CONFLICT (owner_id, observation_date, parameter_code, latitude, longitude)
                        DO UPDATE SET value = EXCLUDED.value, raw_value = EXCLUDED.raw_value,
                                      ingestion_run_id = EXCLUDED.ingestion_run_id, imported_at = now()""",
                        (
                            str(principal.user_id),
                            datetime.strptime(row["date"], "%Y%m%d").date(),
                            row["parameter"],
                            (float(row["value"]) if row["value"] not in (None, -999, -999.0) else None),
                            row["unit"],
                            payload.latitude,
                            payload.longitude,
                            ingestion_run_id,
                            __import__("json").dumps(row),
                        ),
                    )
                    persisted[domain] += 1
                conn.execute(
                    """UPDATE public.ingestion_runs SET status='completed', finished_at=now(),
                       records_received=%s, records_saved=%s WHERE id=%s""",
                    (len(rows), persisted[domain], ingestion_run_id),
                )
                conn.execute(
                    """INSERT INTO public.audit_events
                    (owner_id, event_type, entity_type, entity_id, actor_type, source_id, correlation_id, details)
                    VALUES (%s, 'data_import', %s, %s, 'integration', 'nasa_power', %s, %s::jsonb)""",
                    (str(principal.user_id), table, ingestion_run_id, correlation_id,
                     __import__("json").dumps({"record_count": len(rows), "latitude": payload.latitude,
                                                "longitude": payload.longitude, "start": payload.start_date.isoformat(),
                                                "end": payload.end_date.isoformat(), "parameters": requested})),
                )
        except Exception as exc:  # noqa: BLE001 - report partial success accurately
            persisted[domain] = -1
            app.state.last_ingestion_error = {"domain": domain, "error": type(exc).__name__}
            try:
                with db_hub.user_connection(domain, principal) as conn:
                    conn.execute(
                        """INSERT INTO public.ingestion_runs
                        (owner_id, source_id, target_dataset, status, started_at, finished_at, error_code, request_metadata)
                        VALUES (%s, 'nasa_power', %s, 'failed', now(), now(), %s, %s::jsonb)""",
                        (str(principal.user_id), table, type(exc).__name__,
                         __import__("json").dumps({"latitude": payload.latitude, "longitude": payload.longitude,
                                                    "start": payload.start_date.isoformat(), "end": payload.end_date.isoformat()})),
                    )
            except Exception:
                pass

    return {
        "source": "NASA POWER Daily API",
        "source_url": "https://power.larc.nasa.gov/docs/services/api/temporal/daily/",
        "retrieved_at": datetime.now(__import__("datetime").timezone.utc).isoformat(timespec="seconds"),
        "location": {"latitude": payload.latitude, "longitude": payload.longitude},
        "period": {"start": payload.start_date.isoformat(), "end": payload.end_date.isoformat()},
        "time_standard": "UTC",
        "parameters": requested,
        "record_count": len(rows),
        "records": rows,
        "persistence": persisted,
        "limitations": [
            "Units are read from NASA POWER response metadata when provided; the application fallback is documented in the connector and should be checked against the source parameter/community before downstream modeling.",
            "NASA POWER provides gridded meteorological and solar-resource estimates; the selected grid cell may differ from the exact coordinates. It is not a local farm sensor or electricity meter.",
            "A persistence value of -1 means that domain write failed; inspect server logs and the corresponding database before relying on storage.",
            "Null values and the NASA missing-data code -999 are preserved as missing; do not convert them to zero.",
        ],
    }


def _nasa_unit(parameter: str) -> str:
    units = {
        "T2M": "degC", "T2M_MAX": "degC", "T2M_MIN": "degC",
        "PRECTOTCORR": "mm/day", "RH2M": "%", "WS10M": "m/s", "ALLSKY_SFC_SW_DWN": "MJ/m2/day",
    }
    return units.get(parameter, "source-unit-to-verify")


@app.get("/api/v1/modules/{domain}/snapshot", tags=["workspaces"])
def module_snapshot(domain: str, principal: Principal = Depends(get_current_principal)):
    workspace = next((item for item in WORKSPACES if item["id"] == domain), None)
    if not workspace:
        raise HTTPException(status_code=404, detail="Unknown workspace")
    table_map = {
        "vitalis": ["patient_profiles", "encounters", "clinical_observations"],
        "aquanex": ["water_assets", "telemetry_readings", "water_samples", "water_alerts"],
        "agronex": ["farms", "plots", "crop_cycles", "soil_samples", "weather_observations", "yield_records"],
        "energis": ["energy_sites", "meters", "meter_readings", "resource_observations", "anomalies"],
        "nexora": ["learner_profiles", "learning_resources", "learning_paths", "assessments", "assessment_attempts", "mastery_records"],
    }
    counts = {}
    with db_hub.user_connection(domain, principal) as conn:
        for table in table_map[domain]:
            try:
                row = conn.execute(f"SELECT count(*) AS n FROM {table}").fetchone()
                counts[table] = row["n"]
            except Exception:
                counts[table] = None
    return {"workspace": domain, "counts": counts, "note": "Null means table/schema unavailable or query failed; it is not a zero count."}


def run_server() -> None:
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=False)


if __name__ == "__main__":
    run_server()

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "MISHKAT API"
    environment: str = "development"
    api_prefix: str = "/api/v1"
    auth_mode: str = "development"  # development | supabase_jwks
    dev_auth_enabled: bool = True
    dev_auth_secret: str = "CHANGE-ME-BEFORE-ANY-SHARED-USE-32-CHARS-MINIMUM"
    supabase_jwks_url: str | None = None
    supabase_issuer: str | None = None
    jwt_audience: str = "authenticated"

    vitalis_db_url: str = "postgresql://mishkat_app:local-only-change-me@vitalis-db:5432/vitalis"
    aquanex_db_url: str = "postgresql://mishkat_app:local-only-change-me@aquanex-db:5432/aquanex"
    agronex_db_url: str = "postgresql://mishkat_app:local-only-change-me@agronex-db:5432/agronex"
    energis_db_url: str = "postgresql://mishkat_app:local-only-change-me@energis-db:5432/energis"
    nexora_db_url: str = "postgresql://mishkat_app:local-only-change-me@nexora-db:5432/nexora"

    nasa_power_base_url: str = "https://power.larc.nasa.gov/api/temporal/daily/point"

    cors_origins: str = "http://localhost:8000,http://127.0.0.1:8000"
    request_timeout_seconds: float = 25.0

    @property
    def database_urls(self) -> dict[str, str]:
        return {
            "vitalis": self.vitalis_db_url,
            "aquanex": self.aquanex_db_url,
            "agronex": self.agronex_db_url,
            "energis": self.energis_db_url,
            "nexora": self.nexora_db_url,
        }

    @property
    def allowed_origins(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


settings = Settings()

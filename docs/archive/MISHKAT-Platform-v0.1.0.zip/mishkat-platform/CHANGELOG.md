# Changelog

## 0.1.0 — 2026-11-13
- Initial MISHKAT unified-platform engineering package.
- Five independent PostgreSQL/PostGIS databases and domain schemas.
- Owner-scoped RLS and composite owner-aware foreign keys.
- Unified Arabic RTL responsive frontend and PWA shell.
- FastAPI gateway, local-only development JWT and production JWKS verification path.
- Source registry, ingestion provenance and model registry tables per domain.
- NASA POWER daily data connector with separate AGRONEX/ENERGIS persistence.
- Scientific governance, security, roadmap and acceptance documentation.
